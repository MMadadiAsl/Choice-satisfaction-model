
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 1.05,0.7
set origin 0.0,0.0
set output "Fig1.eps"

set multiplot

######################################################################### 
######################################################################### A

set key at 15.5,1.7 font ",20"
set tics front

set size 0.55,0.67
set origin 0.0,0.0

set xlabel "N (#)"
set ylabel ""

set xtics ("0"0, "5" 5, "10" 10, "15" 15)
set ytics ("0"0)

set xrange [0:15]
set yrange [-1:1]

set title "A                                                                " font ",22"

plot 1.5 * (-exp(-x/5) + 1 - x / 35) w l lc rgb '#0000ff' lt 1 lw 7 title'Benefits', -exp(-x/8) + 1 - x / 9.3 w l lc rgb '#ff0000' lt 1 lw 7 title'Costs', 1.5 * abs(-exp(-x/5) + 1 - x / 35) - abs(-exp(-x/8) + 1 - x / 9.3) w l lc rgb '#408000' lt 1 lw 7 title'Satisfaction', 'zero.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

######################################################################### B1
#########################################################################

set size 0.56,0.4
set origin 0.52,0.4

set xlabel " " font ",20"
set ylabel " " font ",20"

set xrange [0:15]
set yrange [0:1]

set xtics (""0, "" 5, "" 10, "" 15) font ",20"
set ytics ("0.0"0, "0.5"0.5, "1.0"1) font ",20"

set title "                                                       " font ",20"

set label 'B1' at 13,0.75 font ",20"

plot 'outputB1.txt' u 1:2 w l lc 1 lt 1 lw 5 notitle

unset label 1

######################################################################### B2
#########################################################################

set size 0.56,0.4
set origin 0.52,0.2

set xlabel " " font ",20"
set ylabel "Probability" font ",20"

set xrange [0:15]
set yrange [0:0.2]

set xtics (""0, "" 5, "" 10, "" 15) font ",20"
set ytics ("0.0"0, "0.1"0.1, "0.2"0.2) font ",20"

set title "                                                       " font ",20"

set label 'B2' at 13,0.148 font ",20"

plot 'outputB2.txt' u 1:2 w l lc 1 lt 1 lw 5 notitle

unset label 1

######################################################################### B3
#########################################################################

set size 0.56,0.444
set origin 0.52,-0.045

set xlabel "p_i" font ",20"
set ylabel " " font ",20"

set xrange [0:15]
set yrange [0:1]

set xtics ("p_1"0, "p_5" 5, "p_{10}" 10, "p_{15}" 15) font ",20"
set ytics ("0.0"0, "0.5"0.5, "1.0"1) font ",20"

set title "                                                       " font ",20"

set label 'B3' at 13,0.75 font ",20"

plot 0.6 * exp(-x) + 0.02 w l lc 1 lt 1 lw 5 notitle

unset label 1

######################################################################### 
#########################################################################

