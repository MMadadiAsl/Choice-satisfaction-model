
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 1.08,1.31
set origin 0.0,0.0
set output "Fig7.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set key at 24,-5 maxrow 3 font ",20"
set tics front

set size 1.1,0.70
set origin 0.0,0.65

set title "A                                                                                                                                           " font ",22"

set xrange [0:25]
set yrange [0:8]
set ytics ("  1" 1, "4" 4, "7" 7)
set xtics ("r_1" 1, "r_5"5, "r_{9}"9, "r_{13}"13, "r_{17}"17, "r_{21}"21, "r_{25}"25)

set xlabel "r_i"
set ylabel "Rating (points)" offset 0,0

plot 'N4-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 1 pt 7 ps 1.4 title'Group A, N = 4', 'N4-A1.txt' u 1:2 w l lw 3 lt 1 lc 1 notitle, 'N8-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#0000ff' pt 5 ps 1.4 title'Group B, N = 8', 'N8-A1.txt' u 1:2 w l lw 3 lt 1 lc rgb '#0000ff' notitle, 'N12-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#ff0000' pt 9 ps 1.6 title'Group C, N = 12', 'N12-A1.txt' u 1:2 w l lw 3 lt 1 lc rgb '#ff0000' notitle, 'N16-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#408000' pt 65 ps 1.4 title'Group D, N = 16', 'N16-A1.txt' u 1:2 w l lw 3 lt 1 lc rgb '#408000' notitle, 'N20-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 4 pt 64 ps 1.2 title'Group E, N = 20', 'N20-A1.txt' u 1:2 w l lw 3 lt 1 lc 4 notitle, 'N24-A1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#666666' pt 66 ps 1.4 title'Group F, N = 24', 'N24-A1.txt' u 1:2 w l lw 3 lt 1 lc rgb '#666666' notitle, 'line1.txt' u 1:2 w l lt 0 lc 8 lw 2 notitle

################################################################################################################################## B

set size 1.1,0.85
set origin 0.0,-0.04

set title "B                                                                                                                                           " font ",22"

set yrange [-0.025:0.8]
set ytics ("0.0" 0, "0.2" 0.2, "0.4"0.4, "0.6" 0.6, "0.8"0.8)
set xtics ("p_1" 1, "p_5"5, "p_{9}"9, "p_{13}"13, "p_{17}"17, "p_{21}"21, "p_{25}"25)

set xlabel "p_i"
set ylabel "Probability" offset 0,0

plot 'N4-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 1 pt 7 ps 1.4 notitle, 'N4-A2.txt' u 1:2 w l lw 3 lt 1 lc 1 notitle, 'N8-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#0000ff' pt 5 ps 1.4 notitle, 'N8-A2.txt' u 1:2 w l lw 3 lt 1 lc rgb '#0000ff' notitle, 'N12-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#ff0000' pt 9 ps 1.6 notitle, 'N12-A2.txt' u 1:2 w l lw 3 lt 1 lc rgb '#ff0000' notitle, 'N16-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#408000' pt 65 ps 1.4 notitle, 'N16-A2.txt' u 1:2 w l lw 3 lt 1 lc rgb '#408000' notitle, 'N20-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 4 pt 64 ps 1.2 notitle, 'N20-A2.txt' u 1:2 w l lw 3 lt 1 lc 4 notitle, 'N24-A2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#666666' pt 66 ps 1.4 notitle, 'N24-A2.txt' u 1:2 w l lw 3 lt 1 lc rgb '#666666' notitle

##################################################################################################################################

