
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 0.62,1.117
set origin 0.0,0.0
set output "Fig8.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set size 0.65,0.5
set origin 0.0,0.66

set title "A                                                                            " font ",22"

set xrange [0:28]
set yrange [0:8]
set ytics ("  1" 1, "4" 4, "7" 7)
set xtics ("4" 4, "8"8, "12"12, "16"16, "20"20, "24"24)

set xlabel "	"
set ylabel "Rating (points)" offset 0,0

set arrow 1 from 4.4,6 to 7.5,6 heads size screen 1,0,90
set arrow 2 from 8.4,6 to 11.5,6 heads size screen 1,0,90
set arrow 3 from 12.4,6 to 15.5,6 heads size screen 1,0,90
set arrow 4 from 16.4,6 to 19.5,6 heads size screen 1,0,90
set arrow 5 from 20.4,6 to 23.5,6 heads size screen 1,0,90
set arrow 6 from 4.6,2 to 23.5,2 heads size screen 1,0,90

set label 1 '**' at 5.1,6.5 font ",20"
set label 2 '*' at 9.5,6.5 font ",20"
set label 3 'ns' at 13.2,6.85 font ",20"
set label 4 'ns' at 17.2,6.85 font ",20"
set label 5 'ns' at 21.2,6.85 font ",20"
set label 6 '***' at 12.6,1.2 font ",20"
     
plot 'data1.txt' u 1:4:5 with errorbars lw 3 lt 1 lc rgb '#0000ff' pt 7 ps 1.4 notitle, 'data1.txt' u 1:4 w l lw 3 lt 1 lc rgb '#0000ff' notitle, 'line1.txt' u 1:2 w l lt 0 lc 8 lw 2 notitle

unset label 1
unset label 2
unset label 3
unset label 4
unset label 5

################################################################################################################################## B

set size 0.65,0.5
set origin 0.0,0.33

set title "B                                                                            " font ",22"

set xrange [0:28]
set yrange [0:8]
set ytics ("  1" 1, "4" 4, "7" 7)
set xtics ("4" 4, "8"8, "12"12, "16"16, "20"20, "24"24)

set xlabel "	"
set ylabel "Rating (points)" offset 0,0

set label 1 'ns' at 5.2,6.85 font ",20"
set label 2 'ns' at 9.2,6.85 font ",20"
set label 3 'ns' at 13.2,6.85 font ",20"
set label 4 'ns' at 17.2,6.85 font ",20"
set label 5 'ns' at 21.2,6.85 font ",20"

plot 'data1.txt' u 1:2:3 with errorbars lw 3 lt 1 lc rgb '#ff0000' pt 7 ps 1.4 notitle, 'data1.txt' u 1:2 w l lw 3 lt 1 lc rgb '#ff0000' notitle, 'line1.txt' u 1:2 w l lt 0 lc 8 lw 2 notitle

unset label 1
unset label 2
unset label 3
unset label 4
unset label 5

################################################################################################################################## C

set key at 23,1 font ",20"

set size 0.65,0.5
set origin 0.0,0.0

set title "C                                                                            " font ",22"

set xlabel "N (#)"
set ylabel "Rating (points)" offset 0,0

set label 1 '**' at 5.1,6.5 font ",20"
set label 2 'ns' at 9.2,6.85 font ",20"
set label 3 'ns' at 13.2,6.85 font ",20"
set label 4 '*' at 17.4,6.5 font ",20"
set label 5 'ns' at 21.2,6.85 font ",20"

plot 'data2.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 4 pt 7 ps 1.4 notitle, 'data2.txt' u 1:2 w l lw 3 lt 1 lc 4 notitle, 'line1.txt' u 1:2 w l lt 0 lc 8 lw 2 notitle

unset label 1
unset label 2
unset label 3
unset label 4
unset label 5

################################################################################################################################## 






