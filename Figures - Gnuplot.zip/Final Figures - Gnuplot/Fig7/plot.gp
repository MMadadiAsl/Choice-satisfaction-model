
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 1.29,0.75
set origin 0.0,0.0
set output "Fig7.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set key at 23.3,4.0 font ",20" maxrows 3

set size 0.7,0.72
set origin 0.0,0.0

set title "A                                                                                         " font ",22"

set xrange [0:30]
set yrange [0:3.0]

set xtics ("0" 0, "10"10, "20"20, "30"30)
set ytics ("0.0" 0, "1.0" 1.0, "2.0" 2.0, "3.0"3.0, "4.0" 4.0)

set xlabel "N (#)"
set ylabel "I (bits)"

set label 2 'm = 6' at 7.0,0.6
set arrow 1 from 6.7,1.1 to 8.8,0.75 size screen 0.017,15,60 filled lc rgb "#000000" lt -1

plot 'output_a3.0_b5.0.txt' u 1:4 lw 3 lt 1 lc rgb '#862d2d' pt 7 ps 1.1 with linespoints title'a = 3.0, b = 5.0', 'output_a2.0_b3.0.txt' u 1:4 lw 3 lt 1 lc rgb '#f57c00' pt 5 ps 1.0 with linespoints title'a = 2.0, b = 3.0', 'output_a0.2_b1.5.txt' u 1:4 lw 3 lt 1 lc rgb '#ffb74d' pt 9 ps 1.3 with linespoints title'a = 0.2, b = 1.5', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

################################################################################################################################## B

set key at 23.3,4.0 font ",20" maxrows 3

set size 0.7,0.72
set origin 0.62,0.0

set title "B                                                                                         " font ",22"

set xrange [0:30]
set yrange [0:3.0]

set xtics ("0" 0, "10"10, "20"20, "30"30)
set ytics ("0.0" 0, "1.0" 1.0, "2.0" 2.0, "3.0"3.0, "4.0" 4.0)

set xlabel "N (#)"
set ylabel " "

plot 'output_a6.0_b3.0.txt' u 1:4 lw 3 lt 1 lc rgb '#3e226f' pt 7 ps 1.1 with linespoints title'a = 6.0, b = 3.0', 'output_a4.0_b2.0.txt' u 1:4 lw 3 lt 1 lc rgb '#7b1fa2' pt 5 ps 1.0 with linespoints title'a = 4.0, b = 2.0', 'output_a2.0_b1.0.txt' u 1:4 lw 3 lt 1 lc rgb '#ba68c8' pt 9 ps 1.3 with linespoints title'a = 2.0, b = 1.0', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle


