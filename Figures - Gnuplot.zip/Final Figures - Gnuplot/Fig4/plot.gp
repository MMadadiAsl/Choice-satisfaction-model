
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 0.78,0.875
set origin 0.0,0.0
set output "Fig4.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set size 0.8,0.49
set origin 0.0,0.43

set title "A                                                                                                        " font ",22"

set xrange [0:15]
set yrange [0:1.5]

set xtics ("0" 0, "5"5, "10"10, "15"15)
set ytics ("0.0" 0, "0.5"0.5, "1.0" 1.0, "1.5" 1.5)

set xlabel ""
set ylabel "I (bits)"

set label 1 'm = 6' at 2.9,0.39
set arrow 1 from 5.7,0.7 to 4.9,0.49 size screen 0.02,15,60 filled lc rgb "#000000" lt -1

plot 'output.txt' u 1:4 lw 3 lt 1 lc rgb '#408000' pt 7 ps 1.4 with linespoints notitle, 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

unset label 1
unset arrow 1

################################################################################################################################## B

set key at 14.5,2 font ",20"

set size 0.8,0.541
set origin 0.0,0.0

set title "B                                                                                                        " font ",22"

set yrange [0:4]
set ytics ("0.0" 0, "2.0" 2.0, "4.0" 4.0)

set xlabel "N (#)"
set ylabel "H (bits)"

plot 'output.txt' u 1:2 lw 3 lt 1 lc rgb '#0000ff' pt 5 ps 1.4 with linespoints title'H_{max}', 'output.txt' u 1:3 lw 3 lt 1 lc rgb '#ff0000' pt 9 ps 1.7 with linespoints title'H_{obs}', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle


