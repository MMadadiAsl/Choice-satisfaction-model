
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 1.29,0.79
set origin 0.0,0.0
set output "Fig4.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set size 0.65,0.49
set origin 0.0,0.34

set title "A                                                                                   " font ",22"

set xrange [0:30]
set yrange [0:3.0]

set xtics ("0" 0, "10"10, "20"20, "30"30)
set ytics ("0.0" 0, "1.5"1.5, "3.0" 3.0)

set xlabel " "
set ylabel "I (bits)"

set label 1 'a = 0.5, b = 1.0' at 9.1,3.5
set label 2 'm = 6' at 7.0,0.6
set arrow 1 from 6.5,1.4 to 8.3,0.95 size screen 0.017,15,60 filled lc rgb "#000000" lt -1

plot 'output_m6.txt' u 1:4 lw 3 lt 1 lc rgb '#408000' pt 7 ps 1.0 with linespoints notitle, 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

unset label 1
unset label 2
unset arrow 1

################################################################################################################################## B

set key at 29,2.5 font ",20"

set size 0.65,0.5
set origin 0.0,0.0

set title "B                                                                                   " font ",22"

set yrange [0:5]
set ytics ("0.0" 0, "2.5" 2.5, "5.0" 5.0)

set xlabel "N (#)"
set ylabel "H (bits)"

plot 'output_m6.txt' u 1:2 lw 3 lt 1 lc rgb '#0000ff' pt 5 ps 1.0 with linespoints title'H_{max}', 'output_m6.txt' u 1:3 lw 3 lt 1 lc rgb '#ff0000' pt 9 ps 1.3 with linespoints title'H_{obs}', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

################################################################################################################################## C

set key at 27,5.4 font ",20" maxrows 3

set size 0.7,0.72
set origin 0.62,0.0

set title "C                                                                                         " font ",22"

set xrange [0:30]
set yrange [0:4.0]

set xtics ("0" 0, "10"10, "20"20, "30"30)
set ytics ("0.0" 0, "1.0" 1.0, "2.0" 2.0, "3.0"3.0, "4.0" 4.0)

set xlabel "N (#)"
set ylabel "I (bits)"

plot 'output_m14.txt' u 1:4 lw 3 lt 1 lc rgb '#194d33' pt 66 ps 1.2 with linespoints title'm = 14', 'output_m12.txt' u 1:4 lw 3 lt 1 lc rgb '#33691e' pt 64 ps 1.0 with linespoints title'm = 12', 'output_m10.txt' u 1:4 lw 3 lt 1 lc rgb '#388e3c' pt 65 ps 1.0 with linespoints title'm = 10', 'output_m8.txt' u 1:4 lw 3 lt 1 lc rgb '#4caf50' pt 9 ps 1.3 with linespoints title'm = 8', 'output_m6.txt' u 1:4 lw 3 lt 1 lc rgb '#81c784' pt 5 ps 1.0 with linespoints title'm = 6', 'output_m4.txt' u 1:4 lw 3 lt 1 lc rgb '#c8e6c9' pt 7 ps 1.1 with linespoints title'm = 4'


