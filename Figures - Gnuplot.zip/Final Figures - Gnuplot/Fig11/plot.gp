
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 0.62,0.93
set origin 0.0,0.0
set output "Fig11.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A

set key at 28,9.5 font ",16"

set size 0.65,0.53
set origin 0.0,0.44

set title "A                                                                            " font ",22"

set xrange [0:28]
set yrange [0:8]

set xlabel "	"
set ylabel "Rating (points)" offset 0,0

set ytics ("  1" 1, "4" 4, "7" 7)
set xtics ("4" 4, "8"8, "12"12, "16"16, "20"20, "24"24)

set arrow 1 from 4.4,6 to 7.5,6 heads size screen 1,0,90
set arrow 2 from 8.4,6 to 11.5,6 heads size screen 1,0,90
set arrow 3 from 12.4,6 to 15.5,6 heads size screen 1,0,90
set arrow 4 from 16.4,6 to 19.5,6 heads size screen 1,0,90
set arrow 5 from 20.4,6 to 23.5,6 heads size screen 1,0,90
set arrow 6 from 4.6,2 to 11.5,2 heads size screen 1,0,90
set arrow 7 from 12.4,2 to 23.5,2 heads size screen 1,0,90

set label 1 'ns' at 5.2,6.85 font ",20"
set label 2 '*' at 9.5,6.5 font ",20"
set label 3 'ns' at 13.2,6.85 font ",20"
set label 4 '**' at 17.1,6.5 font ",20"
set label 5 'ns' at 21.2,6.85 font ",20"
set label 6 '***' at 7,1.2 font ",20"
set label 7 '***' at 16.5,1.2 font ",20"

plot 'data3.txt' u 1:2:3 with errorbars lw 3 lt 1 lc 1 pt 7 ps 1.4 notitle, 'data3.txt' u 1:2 w l lw 3 lt 1 lc 1 title'Experiment', 'line1.txt' u 1:2 w l lt 0 lc 8 lw 2 notitle

unset label 1
unset label 2
unset label 3
unset label 4
unset label 5
unset label 6
unset label 7
unset arrow 1
unset arrow 2
unset arrow 3
unset arrow 4
unset arrow 5
unset arrow 6
unset arrow 7

################################################################################################################################## B

set key at 28.7,1.025 font ",16"

set size 0.65,0.53
set origin 0.0,0.0

set title "B                                                                            " font ",22"

set xrange [0:28]
set yrange [0.5:0.9]
set ytics ("0.5"0.5, "0.7" 0.7, "0.9"0.9)

set xlabel "N (#)"
set ylabel "I (bits)" offset 0,0

set label 1 'R^2 = 0.947' at 10.8,0.65 font ",18"

plot 'data4.txt' u 1:2 lw 3 lt 1 lc rgb '#408000' pt 7 ps 1.4 title'Model' with linespoints, [4:24] (0.366630) + (0.067591 * x) - (0.002524 * x * x) lw 4 lt 0 lc rgb '#ff0000' title'I = 0.3666 + 0.06759 N - 0.002524 N^2'

unset label 1

##################################################################################################################################




