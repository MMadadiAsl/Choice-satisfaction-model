
set terminal postscript eps enhanced color font "Times-Roman" 22
set size 1.19,0.875
set origin 0.0,0.0
set output "Fig6.eps"
set multiplot
#set colorsequence classic

################################################################################################################################## A1

set key at 13.8,0.7 font ",18"
set tics front

set size 0.55,0.49
set origin 0.0,0.43

set title "A1                                                                     " font ",22"

set xrange [0:14]
set yrange [0:0.8]

set xtics ("p_1" 1, "p_5" 5, "p_9" 9, "p_{13}" 13)
set ytics ("0.0" 0, "0.4"0.4, "0.8" 0.8)

set xlabel ""
set ylabel "Probability"

#set arrow 1 from 2.5,0.5 to 3.5,0.3 size screen 0.02,15,60 filled lc rgb "#000000" lt -1
#set arrow 2 from 4,0.25 to 6,0.18 size screen 0.02,15,60 filled lc rgb "#000000" lt -1

plot 'outputA1-6.txt' u 1:2 lw 3 lt 1 lc rgb '#ffb74d' pt 7 ps 1.0 with linespoints title'N = 6  ', 'outputA1-9.txt' u 1:2 lw 3 lt 1 lc rgb '#f57c00' pt 5 ps 0.9 with linespoints title'N = 9  ', 'outputA1-12.txt' u 1:2 lw 3 lt 1 lc rgb '#862d2d' pt 9 ps 1.2 with linespoints title'N = 12'

#unset arrow 1
#unset arrow 2

################################################################################################################################## A2

set key at 13.8,0.7 font ",18"

set size 0.55,0.585
set origin 0.0,-0.044

set title "A2                                                                     " font ",22"

set xlabel "p_i"
set ylabel "Probability"

plot 'outputA2-6.txt' u 1:2 lw 3 lt 1 lc rgb '#ba68c8' pt 7 ps 1.0 with linespoints title'N = 6  ', 'outputA2-9.txt' u 1:2 lw 3 lt 1 lc rgb '#7b1fa2' pt 5 ps 0.9 with linespoints title'N = 9  ', 'outputA2-12.txt' u 1:2 lw 3 lt 1 lc rgb '#3e226f' pt 9 ps 1.2 with linespoints title'N = 12'

################################################################################################################################## B

set key at 14.8,1.1 font ",16"

set size 0.7,0.49
set origin 0.52,0.43

set title "B                                                                                          " font ",22"

set xrange [0:15]
set yrange [0:1.5]

set xtics ("0" 0, "5"5, "10"10, "15"15)
set ytics ("0.0" 0, "0.5"0.5, "1.0" 1.0, "1.5" 1.5)

set xlabel ""
set ylabel "I (bits)"

set label 1 'm = 6' at 2.9,0.33
set arrow 1 from 5.7,0.7 to 4.9,0.49 size screen 0.02,15,60 filled lc rgb "#000000" lt -1

plot 'information_baseline.txt' u 1:4 lw 3 lt 0 lc rgb '#999999' pt 7 ps 1.4 with linespoints title'Fig. 4A', 'information_A1.txt' u 1:4 lw 3 lt 1 lc rgb '#f57c00' pt 5 ps 1.2 with linespoints title'A1', 'information_A2.txt' u 1:4 lw 3 lt 1 lc rgb '#7b1fa2' pt 9 ps 1.4 with linespoints title'A2', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle

unset label 1
unset arrow 1

################################################################################################################################## C

set key at 14.8,2 font ",16"

set size 0.7,0.541
set origin 0.52,0.0

set title "C                                                                                          " font ",22"

set yrange [0:4]
set ytics ("0.0" 0, "2.0" 2.0, "4.0" 4.0)

set xlabel "N (#)"
set ylabel "H (bits)"

plot 'information_baseline.txt' u 1:2 lw 3 lt 1 lc rgb '#0000ff' pt 13 ps 1.7 with linespoints title'H_{max}', 'information_baseline.txt' u 1:3 lw 3 lt 0 lc rgb '#999999' pt 7 ps 1.4 with linespoints title'H_{obs} - Fig. 4B', 'information_A1.txt' u 1:3 lw 3 lt 1 lc rgb '#f57c00' pt 5 ps 1.2 with linespoints title'H_{obs} - A1', 'information_A2.txt' u 1:3 lw 3 lt 1 lc rgb '#7b1fa2' pt 9 ps 1.4 with linespoints title'H_{obs} - A2', 'ref.txt' u 1:2 w l lc 8 lt 0 lw 4 notitle


